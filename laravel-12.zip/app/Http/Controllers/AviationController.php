<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AviationController extends Controller
{
    //
}
