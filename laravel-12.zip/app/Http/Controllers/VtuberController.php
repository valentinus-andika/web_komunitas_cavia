<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class VtuberController extends Controller
{
    //
}
